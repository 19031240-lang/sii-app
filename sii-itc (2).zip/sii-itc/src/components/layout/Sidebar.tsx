'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import Image from 'next/image';
import { removeToken } from '@/lib/api';
import { LayoutDashboard, Star, BookOpen, Calendar, MapPin, Heart, LogOut, Menu, X, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import clsx from 'clsx';

const navItems = [
  { href: '/dashboard',                    label: 'Inicio',              icon: LayoutDashboard, exact: true },
  { href: '/dashboard/calificaciones',     label: 'Calificaciones',      icon: Star },
  { href: '/dashboard/kardex',             label: 'Kardex',              icon: BookOpen },
  { href: '/dashboard/horario',            label: 'Horario',             icon: Calendar },
  { href: '/dashboard/campus',             label: 'Croquis Campus',      icon: MapPin },
  { href: '/dashboard/profesores',         label: 'Profes Favoritos',    icon: Heart },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  function handleLogout() {
    removeToken();
    router.replace('/login');
  }

  function isActive(item: typeof navItems[0]) {
    return item.exact ? pathname === item.href : pathname.startsWith(item.href);
  }

  const Nav = () => (
    <div className="flex flex-col h-full">
      <div className="p-5 border-b border-white/10 flex items-center gap-3">
        <Image src="/images/logo.png" alt="TEC" width={40} height={40} className="rounded" />
        <div>
          <p className="text-white font-display font-bold text-sm leading-tight">TecNM Celaya</p>
          <p className="text-white/50 text-xs">Portal Estudiantil</p>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const active = isActive(item);
          return (
            <Link key={item.href} href={item.href} onClick={() => setOpen(false)}
              className={clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
                active
                  ? 'bg-white/15 text-white border-l-4 border-green-400 pl-2'
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              )}>
              <item.icon className="w-5 h-5 flex-shrink-0" />
              <span className="flex-1">{item.label}</span>
              {active && <ChevronRight className="w-4 h-4 opacity-50" />}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 border-t border-white/10">
        <button onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:bg-red-500/20 hover:text-red-300 transition-all">
          <LogOut className="w-5 h-5" />
          Cerrar Sesión
        </button>
      </div>
    </div>
  );

  return (
    <>
      <button className="fixed top-4 left-4 z-50 lg:hidden bg-tec-blue text-white p-2 rounded-lg shadow-lg"
        onClick={() => setOpen(!open)}>
        {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {open && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setOpen(false)} />}

      <div className={clsx(
        'fixed left-0 top-0 bottom-0 w-64 sidebar z-50 transition-transform duration-300 lg:hidden',
        open ? 'translate-x-0' : '-translate-x-full'
      )}>
        <Nav />
      </div>

      <div className="hidden lg:flex w-64 flex-shrink-0 sidebar min-h-screen flex-col">
        <Nav />
      </div>
    </>
  );
}
