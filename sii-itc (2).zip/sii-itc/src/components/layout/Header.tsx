'use client';
import Image from 'next/image';
import { Bell } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  return (
    <div className="w-full">
      {/* TEC Banner */}
      <div className="w-full">
        <Image
          src="/images/encabezado.jpg"
          alt="TEC Celaya"
          width={1000}
          height={101}
          className="w-full object-cover"
          priority
        />
      </div>
      {/* Page title bar */}
      <div className="header-bar px-6 py-3 flex items-center justify-between">
        <div>
          <h1 className="text-white font-display font-bold text-xl tracking-wide">{title}</h1>
          {subtitle && <p className="text-white/60 text-xs">{subtitle}</p>}
        </div>
        <button className="text-white/70 hover:text-white transition relative">
          <Bell className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
