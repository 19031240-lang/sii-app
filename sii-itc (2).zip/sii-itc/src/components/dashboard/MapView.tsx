'use client';
import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix leaflet icon paths
delete (L.Icon.Default.prototype as unknown as Record<string, unknown>)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function greenIcon() {
  return new L.Icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  });
}

function blueIcon() {
  return new L.Icon({
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  });
}

function redIcon() {
  return new L.Icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  });
}

interface CampusData {
  name: string;
  lat: number;
  lng: number;
  description: string;
  color: string;
}

interface MapViewProps {
  campus1: CampusData;
  campus2: CampusData;
  userPos: { lat: number; lng: number } | null;
  activeCampus: 'campus1' | 'campus2';
}

function FlyTo({ activeCampus, campus1, campus2 }: { activeCampus: string; campus1: CampusData; campus2: CampusData }) {
  const map = useMap();
  useEffect(() => {
    const target = activeCampus === 'campus1' ? campus1 : campus2;
    map.flyTo([target.lat, target.lng], 17, { duration: 1 });
  }, [activeCampus, campus1, campus2, map]);
  return null;
}

export default function MapView({ campus1, campus2, userPos, activeCampus }: MapViewProps) {
  return (
    <MapContainer
      center={[campus1.lat, campus1.lng]}
      zoom={16}
      style={{ height: '100%', width: '100%' }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <FlyTo activeCampus={activeCampus} campus1={campus1} campus2={campus2} />

      {/* Campus 1 */}
      <Marker position={[campus1.lat, campus1.lng]} icon={greenIcon()}>
        <Popup>
          <div className="text-sm">
            <p className="font-bold text-green-700">{campus1.name}</p>
            <p className="text-gray-600 mt-1">{campus1.description}</p>
          </div>
        </Popup>
      </Marker>

      {/* Campus 2 */}
      <Marker position={[campus2.lat, campus2.lng]} icon={blueIcon()}>
        <Popup>
          <div className="text-sm">
            <p className="font-bold text-blue-700">{campus2.name}</p>
            <p className="text-gray-600 mt-1">{campus2.description}</p>
          </div>
        </Popup>
      </Marker>

      {/* User location */}
      {userPos && (
        <Marker position={[userPos.lat, userPos.lng]} icon={redIcon()}>
          <Popup>
            <p className="text-sm font-bold text-red-600">📍 Tu ubicación actual</p>
          </Popup>
        </Marker>
      )}
    </MapContainer>
  );
}
