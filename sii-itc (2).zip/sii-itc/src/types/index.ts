export interface LoginResponse {
  token: string;
  user?: StudentProfile;
}

export interface StudentProfile {
  nombre?: string;
  apellidos?: string;
  matricula?: string;
  carrera?: string;
  semestre?: string | number;
  email?: string;
  foto?: string;
  promedio?: number | string;
  creditos?: number | string;
  estatus?: string;
  [key: string]: unknown;
}

export interface Calificacion {
  materia?: string;
  nombre_materia?: string;
  periodo?: string;
  calificacion?: number | string;
  calificacion_final?: number | string;
  creditos?: number | string;
  [key: string]: unknown;
}

export interface KardexItem {
  materia?: string;
  nombre?: string;
  periodo?: string;
  calificacion?: number | string;
  creditos?: number | string;
  semestre?: number | string;
  estatus?: string;
  [key: string]: unknown;
}

export interface HorarioItem {
  materia?: string;
  nombre_materia?: string;
  dia?: string;
  hora_inicio?: string;
  hora_fin?: string;
  salon?: string;
  maestro?: string;
  grupo?: string;
  [key: string]: unknown;
}
