'use client';
import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { loginUser, setToken } from '@/lib/api';
import { Eye, EyeOff, LogIn, AlertCircle } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');

    if (!email.trim()) { setError('Ingresa tu correo institucional.'); return; }
    if (!password.trim()) { setError('Ingresa tu contraseña.'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Ingresa un correo válido (ej: l12345678@celaya.tecnm.mx)');
      return;
    }

    setLoading(true);
    try {
      const data = await loginUser(email.trim(), password);
      if (data.token) {
        setToken(String(data.token));
        router.replace('/dashboard');
      } else {
        setError('El servidor no devolvió una sesión válida. Intenta de nuevo.');
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Error de conexión. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen login-bg flex flex-col">
      <div className="w-full">
        <Image src="/images/encabezado.jpg" alt="TEC Celaya" width={1000} height={101}
          className="w-full object-cover" priority />
      </div>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md fade-in">
          <div className="flex justify-center mb-6">
            <div className="bg-white rounded-full p-3 shadow-2xl">
              <Image src="/images/identidad.webp" alt="ISC" width={100} height={100} className="rounded-full" />
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-tec-green to-tec-blue p-6 text-white text-center">
              <h1 className="font-display text-2xl font-bold tracking-wide">PORTAL ESTUDIANTIL</h1>
              <p className="text-sm opacity-75 mt-1">Tecnológico Nacional de México en Celaya</p>
            </div>

            <div className="p-8">
              <p className="text-center text-sm text-gray-500 mb-6">
                Ingresa con tus credenciales del <span className="font-semibold text-tec-blue">SII ITC</span>
              </p>

              {error && (
                <div className="mb-5 flex items-start gap-3 bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Correo Institucional
                  </label>
                  <input
                    type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="l12345678@celaya.tecnm.mx"
                    disabled={loading} autoComplete="email" spellCheck={false}
                    className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-tec-green focus:border-transparent transition disabled:opacity-50 disabled:bg-gray-50"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Contraseña</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'} value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="••••••••" disabled={loading} autoComplete="current-password"
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-tec-green focus:border-transparent transition disabled:opacity-50 disabled:bg-gray-50"
                    />
                    <button type="button" onClick={() => setShowPassword(v => !v)} tabIndex={-1}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition">
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <button type="submit" disabled={loading}
                  className="w-full bg-gradient-to-r from-tec-green to-tec-blue text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 active:scale-[0.98] transition-all disabled:opacity-60 disabled:cursor-not-allowed">
                  {loading ? (
                    <><div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />Iniciando sesión...</>
                  ) : (
                    <><LogIn className="w-5 h-5" />Iniciar Sesión</>
                  )}
                </button>
              </form>

              <p className="text-xs text-center text-gray-400 mt-6">
                Usa las mismas credenciales del sistema SII ITC Celaya
              </p>
            </div>
          </div>

          <p className="text-center text-white/50 text-xs mt-4">
            © {new Date().getFullYear()} TecNM Campus Celaya — ISC
          </p>
        </div>
      </div>
    </div>
  );
}
