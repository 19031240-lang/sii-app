'use client';
import { useEffect, useState } from 'react';
import Header from '@/components/layout/Header';
import { Heart, Star, Plus, Trash2, MessageCircle, X, ChevronDown, ChevronUp, Edit2, Check } from 'lucide-react';
import Image from 'next/image';
import clsx from 'clsx';

interface Comentario {
  id: string;
  texto: string;
  fecha: string;
  rating: number;
}

interface Profesor {
  id: string;
  nombre: string;
  materia: string;
  departamento: string;
  avatar: string;
  favorito: boolean;
  comentarios: Comentario[];
}

const STORAGE_KEY = 'sii_profesores';

const AVATARS = [
  'https://api.dicebear.com/8.x/initials/svg?seed=',
];

const DEPARTAMENTOS = [
  'Sistemas Computacionales','Electrónica','Industrial','Civil','Mecánica','Administración','Ciencias Básicas',
];

function getInitials(name: string) {
  return name.split(' ').slice(0,2).map(n => n[0]).join('').toUpperCase();
}

function StarRating({ value, onChange }: { value: number; onChange?: (v: number) => void }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-0.5">
      {[1,2,3,4,5].map(s => (
        <button key={s} type="button"
          onClick={() => onChange?.(s)}
          onMouseEnter={() => onChange && setHover(s)}
          onMouseLeave={() => onChange && setHover(0)}
          className={clsx('transition', onChange ? 'cursor-pointer' : 'cursor-default')}>
          <Star className={clsx('w-4 h-4', (hover || value) >= s ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300')} />
        </button>
      ))}
    </div>
  );
}

function loadProfesores(): Profesor[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : getDefault();
  } catch { return getDefault(); }
}

function saveProfesores(profs: Profesor[]) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(profs)); } catch {}
}

function getDefault(): Profesor[] {
  return [
    { id: '1', nombre: 'Dr. Carlos Ramírez', materia: 'Programación Web', departamento: 'Sistemas Computacionales',
      avatar: '', favorito: true, comentarios: [
        { id: 'c1', texto: 'Explica muy bien los temas de React y Next.js. Sus clases son muy dinámicas.', fecha: '2024-03-10', rating: 5 },
        { id: 'c2', texto: 'Deja tareas desafiantes pero aprendo mucho.', fecha: '2024-04-01', rating: 4 },
      ]},
    { id: '2', nombre: 'Mtra. Laura Sánchez', materia: 'Bases de Datos', departamento: 'Sistemas Computacionales',
      avatar: '', favorito: true, comentarios: [
        { id: 'c3', texto: 'Sus ejemplos con MySQL son muy claros y aplicables.', fecha: '2024-02-20', rating: 5 },
      ]},
    { id: '3', nombre: 'Ing. Marco Torres', materia: 'Redes de Computadoras', departamento: 'Sistemas Computacionales',
      avatar: '', favorito: false, comentarios: [] },
  ];
}

export default function ProfesoresPage() {
  const [profesores, setProfesores] = useState<Profesor[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [expandido, setExpandido] = useState<string | null>(null);
  const [editandoComentario, setEditandoComentario] = useState<{profId: string; texto: string; rating: number} | null>(null);
  const [filtro, setFiltro] = useState<'todos' | 'favoritos'>('todos');
  const [nuevoProf, setNuevoProf] = useState({ nombre: '', materia: '', departamento: DEPARTAMENTOS[0] });
  const [formError, setFormError] = useState('');

  useEffect(() => { setProfesores(loadProfesores()); }, []);

  function update(profs: Profesor[]) { setProfesores(profs); saveProfesores(profs); }

  function toggleFavorito(id: string) {
    update(profesores.map(p => p.id === id ? { ...p, favorito: !p.favorito } : p));
  }

  function eliminarProfesor(id: string) {
    if (!confirm('¿Eliminar este profesor de tu lista?')) return;
    update(profesores.filter(p => p.id !== id));
  }

  function agregarProfesor() {
    setFormError('');
    if (!nuevoProf.nombre.trim()) { setFormError('El nombre es requerido.'); return; }
    if (!nuevoProf.materia.trim()) { setFormError('La materia es requerida.'); return; }
    const nuevo: Profesor = {
      id: Date.now().toString(),
      nombre: nuevoProf.nombre.trim(),
      materia: nuevoProf.materia.trim(),
      departamento: nuevoProf.departamento,
      avatar: '',
      favorito: false,
      comentarios: [],
    };
    update([...profesores, nuevo]);
    setNuevoProf({ nombre: '', materia: '', departamento: DEPARTAMENTOS[0] });
    setShowForm(false);
  }

  function agregarComentario(profId: string) {
    if (!editandoComentario || editandoComentario.profId !== profId) return;
    if (!editandoComentario.texto.trim()) return;
    const comentario: Comentario = {
      id: Date.now().toString(),
      texto: editandoComentario.texto.trim(),
      fecha: new Date().toISOString().split('T')[0],
      rating: editandoComentario.rating || 5,
    };
    update(profesores.map(p => p.id === profId
      ? { ...p, comentarios: [...p.comentarios, comentario] }
      : p
    ));
    setEditandoComentario(null);
  }

  function eliminarComentario(profId: string, comentId: string) {
    update(profesores.map(p => p.id === profId
      ? { ...p, comentarios: p.comentarios.filter(c => c.id !== comentId) }
      : p
    ));
  }

  const filtrados = profesores.filter(p => filtro === 'favoritos' ? p.favorito : true);
  const totalFavs = profesores.filter(p => p.favorito).length;

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Profesores Favoritos" subtitle="Guarda y comenta sobre tus profesores" />
      <main className="flex-1 p-4 lg:p-6">
        <div className="max-w-4xl mx-auto fade-in space-y-5">

          {/* Stats + actions */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex gap-3">
              <button onClick={() => setFiltro('todos')}
                className={clsx('px-4 py-2 rounded-lg text-sm font-medium transition-all border',
                  filtro === 'todos' ? 'bg-tec-blue text-white border-tec-blue' : 'bg-white text-gray-600 border-gray-200 hover:border-tec-blue')}>
                Todos ({profesores.length})
              </button>
              <button onClick={() => setFiltro('favoritos')}
                className={clsx('flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all border',
                  filtro === 'favoritos' ? 'bg-red-500 text-white border-red-500' : 'bg-white text-gray-600 border-gray-200 hover:border-red-400')}>
                <Heart className="w-4 h-4" /> Favoritos ({totalFavs})
              </button>
            </div>
            <button onClick={() => setShowForm(v => !v)}
              className="flex items-center gap-2 bg-gradient-to-r from-tec-green to-tec-blue text-white px-4 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition-all shadow">
              {showForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {showForm ? 'Cancelar' : 'Agregar Profesor'}
            </button>
          </div>

          {/* Formulario nuevo profesor */}
          {showForm && (
            <div className="card-tec p-5 fade-in">
              <h3 className="font-bold text-tec-blue mb-4 flex items-center gap-2">
                <Plus className="w-5 h-5" /> Agregar nuevo profesor
              </h3>
              {formError && (
                <p className="text-red-600 text-sm mb-3 bg-red-50 border border-red-200 rounded-lg px-3 py-2">{formError}</p>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Nombre completo *</label>
                  <input value={nuevoProf.nombre} onChange={e => setNuevoProf(v => ({...v, nombre: e.target.value}))}
                    placeholder="Dr. Juan Pérez" maxLength={100}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-tec-green" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Materia que imparte *</label>
                  <input value={nuevoProf.materia} onChange={e => setNuevoProf(v => ({...v, materia: e.target.value}))}
                    placeholder="Programación Web" maxLength={100}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-tec-green" />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-gray-600 mb-1">Departamento</label>
                  <select value={nuevoProf.departamento} onChange={e => setNuevoProf(v => ({...v, departamento: e.target.value}))}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-tec-green bg-white">
                    {DEPARTAMENTOS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
              </div>
              <div className="flex gap-3 mt-4">
                <button onClick={agregarProfesor}
                  className="flex items-center gap-2 bg-tec-green text-white px-5 py-2 rounded-lg text-sm font-semibold hover:bg-green-700 transition">
                  <Check className="w-4 h-4" /> Guardar
                </button>
                <button onClick={() => { setShowForm(false); setFormError(''); }}
                  className="px-5 py-2 rounded-lg text-sm border border-gray-300 text-gray-600 hover:bg-gray-50 transition">
                  Cancelar
                </button>
              </div>
            </div>
          )}

          {/* Lista de profesores */}
          {filtrados.length === 0 && (
            <div className="text-center py-16 text-gray-400">
              <Heart className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>{filtro === 'favoritos' ? 'No tienes profesores favoritos aún.' : 'No hay profesores en tu lista.'}</p>
              <button onClick={() => setShowForm(true)} className="mt-3 text-tec-blue text-sm underline">
                Agregar uno
              </button>
            </div>
          )}

          {filtrados.map(prof => {
            const promRating = prof.comentarios.length
              ? (prof.comentarios.reduce((s,c) => s+c.rating, 0) / prof.comentarios.length).toFixed(1)
              : null;
            const isExpanded = expandido === prof.id;
            const isCommenting = editandoComentario?.profId === prof.id;

            return (
              <div key={prof.id} className="card-tec overflow-hidden">
                <div className="p-5">
                  <div className="flex items-start gap-4">
                    {/* Avatar */}
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-tec-green to-tec-blue flex items-center justify-center flex-shrink-0 shadow">
                      <span className="text-white font-bold text-lg">{getInitials(prof.nombre)}</span>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-bold text-gray-800 text-base leading-tight">{prof.nombre}</h3>
                          <p className="text-tec-green font-medium text-sm mt-0.5">{prof.materia}</p>
                          <p className="text-gray-400 text-xs mt-0.5">{prof.departamento}</p>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <button onClick={() => toggleFavorito(prof.id)} title={prof.favorito ? 'Quitar favorito' : 'Marcar favorito'}
                            className="p-1.5 rounded-full hover:bg-red-50 transition">
                            <Heart className={clsx('w-5 h-5 transition', prof.favorito ? 'text-red-500 fill-red-500' : 'text-gray-300 hover:text-red-400')} />
                          </button>
                          <button onClick={() => eliminarProfesor(prof.id)} title="Eliminar"
                            className="p-1.5 rounded-full hover:bg-red-50 transition">
                            <Trash2 className="w-4 h-4 text-gray-300 hover:text-red-500 transition" />
                          </button>
                        </div>
                      </div>

                      {/* Rating y comentarios count */}
                      <div className="flex items-center gap-3 mt-2">
                        {promRating && (
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                            <span className="text-sm font-bold text-gray-700">{promRating}</span>
                          </div>
                        )}
                        <span className="text-xs text-gray-400">
                          {prof.comentarios.length} comentario{prof.comentarios.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions bar */}
                  <div className="flex gap-2 mt-4 pt-4 border-t border-gray-100">
                    <button
                      onClick={() => setExpandido(isExpanded ? null : prof.id)}
                      className="flex items-center gap-1.5 text-xs text-tec-blue font-medium hover:underline transition">
                      <MessageCircle className="w-4 h-4" />
                      {isExpanded ? 'Ocultar' : 'Ver comentarios'}
                      {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>
                    <button
                      onClick={() => {
                        setExpandido(prof.id);
                        setEditandoComentario(isCommenting ? null : { profId: prof.id, texto: '', rating: 5 });
                      }}
                      className="flex items-center gap-1.5 text-xs text-tec-green font-medium hover:underline transition ml-auto">
                      <Edit2 className="w-4 h-4" />
                      {isCommenting ? 'Cancelar' : 'Comentar'}
                    </button>
                  </div>
                </div>

                {/* Comentarios expandidos */}
                {isExpanded && (
                  <div className="bg-gray-50 border-t border-gray-100 p-4 space-y-3">

                    {/* Nuevo comentario */}
                    {isCommenting && editandoComentario && (
                      <div className="bg-white rounded-xl p-4 border border-tec-green/20 shadow-sm fade-in">
                        <p className="text-xs font-semibold text-tec-green mb-2">Nuevo comentario</p>
                        <div className="mb-2">
                          <label className="text-xs text-gray-500 mb-1 block">Calificación</label>
                          <StarRating value={editandoComentario.rating}
                            onChange={v => setEditandoComentario(ec => ec ? {...ec, rating: v} : ec)} />
                        </div>
                        <textarea
                          value={editandoComentario.texto}
                          onChange={e => setEditandoComentario(ec => ec ? {...ec, texto: e.target.value} : ec)}
                          placeholder="¿Qué opinas de este profesor? Sus clases, metodología, trato..."
                          rows={3} maxLength={500}
                          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-tec-green mt-1"
                        />
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-gray-400">{editandoComentario.texto.length}/500</span>
                          <button onClick={() => agregarComentario(prof.id)}
                            disabled={!editandoComentario.texto.trim()}
                            className="flex items-center gap-1.5 bg-tec-green text-white px-4 py-1.5 rounded-lg text-xs font-semibold disabled:opacity-50 hover:bg-green-700 transition">
                            <Check className="w-3 h-3" /> Publicar
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Lista de comentarios */}
                    {prof.comentarios.length === 0 && !isCommenting && (
                      <p className="text-center text-gray-400 text-sm py-4">
                        Sin comentarios aún. ¡Sé el primero en opinar!
                      </p>
                    )}

                    {prof.comentarios.map(com => (
                      <div key={com.id} className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <StarRating value={com.rating} />
                              <span className="text-xs text-gray-400">{com.fecha}</span>
                            </div>
                            <p className="text-sm text-gray-700 leading-relaxed">{com.texto}</p>
                          </div>
                          <button onClick={() => eliminarComentario(prof.id, com.id)}
                            className="text-gray-300 hover:text-red-400 transition flex-shrink-0 p-1">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
