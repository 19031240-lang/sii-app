'use client';
import { useEffect, useState, useRef } from 'react';
import { getEstudiante, unwrap } from '@/lib/api';
import Header from '@/components/layout/Header';
import { User, BookOpen, Award, Hash, Mail, BarChart2, AlertCircle, Camera, RefreshCw } from 'lucide-react';
import Image from 'next/image';

interface Profile { [key: string]: unknown }

function getField(p: Profile, keys: string[]): string {
  for (const k of keys) if (p[k] !== undefined && p[k] !== null && p[k] !== '') return String(p[k]);
  return '';
}

export default function DashboardPage() {
  const [student, setStudent] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function load() {
    setLoading(true); setError('');
    const saved = localStorage.getItem('student_photo');
    if (saved) setPhoto(saved);
    getEstudiante()
      .then((data) => { setStudent(unwrap(data) as Profile); })
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(); }, []);

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setPhoto(result);
      localStorage.setItem('student_photo', result);
    };
    reader.readAsDataURL(file);
  }

  const s = student ?? {};
  const nombre     = getField(s, ['nombre','nombre_completo','name','first_name']);
  const apellidos  = getField(s, ['apellidos','apellido','last_name','surname']);
  const carrera    = getField(s, ['carrera','especialidad','programa','career']);
  const matricula  = getField(s, ['matricula','no_control','numero_control','id_alumno']);
  const correo     = getField(s, ['email','correo','mail']);
  const semestre   = getField(s, ['semestre','periodo','semester']);
  const promedio   = getField(s, ['promedio','promedio_general','gpa','average']);
  const creditos   = getField(s, ['creditos','creditos_aprobados','credits']);
  const estatus    = getField(s, ['estatus','status','estado']);
  const fotoSrc    = photo || getField(s, ['foto','imagen','avatar','picture','photo']);

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Mi Perfil" subtitle="Información del estudiante" />
      <main className="flex-1 p-4 lg:p-6">

        {loading && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="spinner" />
            <p className="text-gray-400 text-sm">Cargando datos del estudiante...</p>
          </div>
        )}

        {error && (
          <div className="max-w-2xl mx-auto mt-6 bg-red-50 border border-red-200 rounded-xl p-5 flex items-start gap-3 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">Error al cargar datos</p>
              <p className="text-sm mt-1">{error}</p>
            </div>
            <button onClick={load} className="flex items-center gap-1 text-sm underline hover:no-underline">
              <RefreshCw className="w-4 h-4" /> Reintentar
            </button>
          </div>
        )}

        {!loading && !error && student && (
          <div className="max-w-4xl mx-auto fade-in space-y-5">

            {/* Hero card */}
            <div className="card-tec p-6 flex flex-col sm:flex-row items-center gap-6">
              <div className="relative flex-shrink-0">
                <div className="w-28 h-28 rounded-full overflow-hidden border-4 border-tec-green shadow-lg bg-gray-100">
                  {fotoSrc ? (
                    <Image src={fotoSrc} alt="Foto de perfil" width={112} height={112}
                      className="object-cover w-full h-full" unoptimized />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-tec-green to-tec-blue">
                      <User className="w-14 h-14 text-white opacity-80" />
                    </div>
                  )}
                </div>
                <button onClick={() => fileRef.current?.click()}
                  className="absolute bottom-0 right-0 bg-tec-green text-white rounded-full p-1.5 shadow-lg hover:bg-green-700 transition"
                  title="Cambiar foto de perfil">
                  <Camera className="w-4 h-4" />
                </button>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
              </div>

              <div className="flex-1 text-center sm:text-left">
                <h2 className="text-xl lg:text-2xl font-display font-bold text-tec-blue leading-tight">
                  {[nombre, apellidos].filter(Boolean).join(' ') || 'Estudiante'}
                </h2>
                {carrera && <p className="text-tec-green font-semibold mt-1 text-sm">{carrera}</p>}
                <div className="flex flex-wrap gap-2 mt-3 justify-center sm:justify-start">
                  {matricula && (
                    <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 text-xs px-3 py-1 rounded-full font-medium">
                      <Hash className="w-3 h-3" />{matricula}
                    </span>
                  )}
                  {semestre && (
                    <span className="inline-flex items-center gap-1 bg-green-50 text-green-700 text-xs px-3 py-1 rounded-full font-medium">
                      <BookOpen className="w-3 h-3" />Sem. {semestre}
                    </span>
                  )}
                  {estatus && (
                    <span className="inline-flex items-center gap-1 bg-gray-100 text-gray-600 text-xs px-3 py-1 rounded-full font-medium">
                      {estatus}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={<Hash className="w-5 h-5 text-tec-blue" />} label="Matrícula" value={matricula || '—'} />
              <StatCard icon={<Mail className="w-5 h-5 text-tec-green" />} label="Correo" value={correo || '—'} small />
              <StatCard icon={<BarChart2 className="w-5 h-5 text-yellow-600" />} label="Promedio" value={promedio || '—'} />
              <StatCard icon={<Award className="w-5 h-5 text-purple-600" />} label="Créditos" value={creditos || '—'} />
            </div>

            {/* Datos completos */}
            <div className="card-tec p-5">
              <h3 className="font-bold text-tec-blue mb-4 text-sm uppercase tracking-wide">Datos completos del perfil</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6">
                {Object.entries(student)
                  .filter(([, v]) => v !== null && v !== undefined && v !== '')
                  .map(([key, val]) => (
                    <div key={key} className="flex gap-2 text-sm border-b border-gray-50 pb-2">
                      <span className="text-gray-400 capitalize min-w-[110px] flex-shrink-0 text-xs pt-0.5">
                        {key.replace(/_/g,' ')}
                      </span>
                      <span className="text-gray-800 font-medium break-all text-sm">
                        {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function StatCard({ icon, label, value, small }: { icon: React.ReactNode; label: string; value: string; small?: boolean }) {
  return (
    <div className="card-tec p-4 flex flex-col items-center text-center gap-1">
      <div className="mb-1">{icon}</div>
      <p className="text-gray-400 text-xs uppercase tracking-wide">{label}</p>
      <p className={`font-bold text-gray-800 ${small ? 'text-xs break-all' : 'text-base'}`}>{value}</p>
    </div>
  );
}
