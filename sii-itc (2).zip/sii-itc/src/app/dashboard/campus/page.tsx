'use client';
import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import Header from '@/components/layout/Header';
import { MapPin, Navigation, Info } from 'lucide-react';

// Lazy load the map to avoid SSR issues
const MapView = dynamic(() => import('@/components/dashboard/MapView'), { ssr: false, loading: () => (
  <div className="flex items-center justify-center h-[500px] bg-gray-100 rounded-xl">
    <div className="spinner" />
  </div>
) });

const CAMPUS_1 = {
  name: 'Campus 1 — Principal',
  lat: 20.5231,
  lng: -100.8109,
  description: 'Campus principal del TecNM Celaya. Edificios administrativos, aulas, biblioteca y laboratorios.',
  color: '#006633',
};

const CAMPUS_2 = {
  name: 'Campus 2 — Laboratorios',
  lat: 20.5198,
  lng: -100.8078,
  description: 'Campus de laboratorios avanzados e ingeniería. Talleres, centros de cómputo y canchas.',
  color: '#003F8A',
};

export default function CampusPage() {
  const [userPos, setUserPos] = useState<{ lat: number; lng: number } | null>(null);
  const [gpsError, setGpsError] = useState('');
  const [activeCampus, setActiveCampus] = useState<'campus1' | 'campus2'>('campus1');

  function getLocation() {
    if (!navigator.geolocation) {
      setGpsError('Geolocalización no soportada en este navegador.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGpsError('');
      },
      () => setGpsError('No se pudo obtener tu ubicación. Verifica los permisos.')
    );
  }

  useEffect(() => { getLocation(); }, []);

  function distanceTo(lat: number, lng: number): string {
    if (!userPos) return '—';
    const R = 6371000;
    const dLat = ((lat - userPos.lat) * Math.PI) / 180;
    const dLng = ((lng - userPos.lng) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos((userPos.lat * Math.PI) / 180) * Math.cos((lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
    const dist = R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return dist < 1000 ? `${Math.round(dist)} m` : `${(dist / 1000).toFixed(1)} km`;
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Croquis del Campus" subtitle="Ubicación GPS de Campus 1 y Campus 2" />

      <main className="flex-1 p-6">
        <div className="max-w-5xl mx-auto fade-in space-y-5">
          {/* Campus selector */}
          <div className="flex gap-3">
            {[['campus1', CAMPUS_1], ['campus2', CAMPUS_2]].map(([key, c]) => {
              const campus = c as typeof CAMPUS_1;
              return (
                <button
                  key={key as string}
                  onClick={() => setActiveCampus(key as 'campus1' | 'campus2')}
                  className={`flex-1 py-3 px-4 rounded-xl font-semibold text-sm transition-all border-2 ${
                    activeCampus === key
                      ? 'bg-tec-green text-white border-tec-green shadow-md'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-tec-green'
                  }`}
                >
                  {campus.name}
                </button>
              );
            })}
          </div>

          {/* GPS bar */}
          <div className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm ${
            userPos ? 'bg-green-50 text-green-700' : 'bg-yellow-50 text-yellow-700'
          }`}>
            <Navigation className="w-4 h-4 flex-shrink-0" />
            {userPos ? (
              <span>Tu ubicación: {userPos.lat.toFixed(5)}, {userPos.lng.toFixed(5)}</span>
            ) : (
              <span>{gpsError || 'Obteniendo ubicación GPS...'}</span>
            )}
            {!userPos && (
              <button onClick={getLocation} className="ml-auto text-xs underline">Reintentar</button>
            )}
          </div>

          {/* Campus info cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[CAMPUS_1, CAMPUS_2].map((campus) => (
              <div key={campus.name} className="card-tec p-4 flex items-start gap-3">
                <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: campus.color }} />
                <div>
                  <p className="font-bold text-sm text-gray-800">{campus.name}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{campus.description}</p>
                  <p className="text-xs text-tec-blue font-medium mt-1">
                    Distancia: {distanceTo(campus.lat, campus.lng)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Map */}
          <div className="card-tec overflow-hidden" style={{ height: 500 }}>
            <MapView
              campus1={CAMPUS_1}
              campus2={CAMPUS_2}
              userPos={userPos}
              activeCampus={activeCampus}
            />
          </div>

          <div className="flex items-start gap-2 text-xs text-gray-400">
            <Info className="w-4 h-4 flex-shrink-0" />
            <p>
              Las coordenadas del campus son aproximadas. Para navegación precisa usa Google Maps.
              Haz clic en los marcadores del mapa para más información.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
