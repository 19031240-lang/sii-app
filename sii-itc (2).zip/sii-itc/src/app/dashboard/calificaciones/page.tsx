'use client';
import { useEffect, useState } from 'react';
import { getCalificaciones, unwrap } from '@/lib/api';
import Header from '@/components/layout/Header';
import { Search, AlertCircle, TrendingUp, TrendingDown, Minus, RefreshCw } from 'lucide-react';

interface Cal { [key: string]: unknown }

function getF(item: Cal, keys: string[]): string {
  for (const k of keys) if (item[k] !== undefined && item[k] !== null && item[k] !== '') return String(item[k]);
  return '';
}

function gradeNum(item: Cal): number {
  return parseFloat(getF(item, ['calificacion','calificacion_final','calif','grade','nota','score']));
}

function GradeBadge({ item }: { item: Cal }) {
  const g = gradeNum(item);
  const val = getF(item, ['calificacion','calificacion_final','calif','grade','nota','score']);
  if (!val) return <span className="text-gray-400 text-sm">pendiente</span>;
  const isNum = !isNaN(g);
  const cls = !isNum ? 'bg-gray-100 text-gray-600' : g >= 80 ? 'grade-green' : g >= 70 ? 'grade-yellow' : 'grade-red';
  const icon = !isNum ? null : g >= 80
    ? <TrendingUp className="w-3 h-3" />
    : g >= 70 ? <Minus className="w-3 h-3" />
    : <TrendingDown className="w-3 h-3" />;
  return <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${cls}`}>{icon}{val}</span>;
}

export default function CalificacionesPage() {
  const [items, setItems] = useState<Cal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [periodoFilter, setPeriodoFilter] = useState('');

  function load() {
    setLoading(true); setError('');
    getCalificaciones()
      .then((data) => {
        const u = unwrap(data);
        setItems(Array.isArray(u) ? u as Cal[] : [u as Cal].filter(Boolean));
      })
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(); }, []);

  const periodos = Array.from(new Set(items.map(i => getF(i,['periodo','ciclo','semestre'])).filter(Boolean)));
  const filtered = items.filter(item => {
    const n = getF(item,['materia','nombre_materia','nombre','asignatura']).toLowerCase();
    const p = getF(item,['periodo','ciclo','semestre']);
    return n.includes(search.toLowerCase()) && (!periodoFilter || p === periodoFilter);
  });
  const grades = items.map(gradeNum).filter(n => !isNaN(n) && n > 0);
  const avg = grades.length ? (grades.reduce((a,b)=>a+b,0)/grades.length).toFixed(1) : null;
  const aprobadas = grades.filter(g => g >= 70).length;

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Calificaciones" subtitle="Materias y calificaciones del periodo actual" />
      <main className="flex-1 p-4 lg:p-6">
        <div className="max-w-5xl mx-auto fade-in space-y-4">
          {!loading && items.length > 0 && (
            <div className="grid grid-cols-3 gap-3">
              <div className="card-tec p-3 text-center"><p className="text-xl font-bold text-tec-blue">{items.length}</p><p className="text-xs text-gray-400 mt-0.5">Total</p></div>
              <div className="card-tec p-3 text-center"><p className="text-xl font-bold text-tec-green">{avg ?? 'pendiente'}</p><p className="text-xs text-gray-400 mt-0.5">Promedio</p></div>
              <div className="card-tec p-3 text-center"><p className="text-xl font-bold text-yellow-600">{aprobadas}</p><p className="text-xs text-gray-400 mt-0.5">Aprobadas</p></div>
            </div>
          )}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar materia..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-tec-green bg-white" />
            </div>
            {periodos.length > 0 && (
              <select value={periodoFilter} onChange={e => setPeriodoFilter(e.target.value)}
                className="border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-tec-green bg-white">
                <option value="">Todos los periodos</option>
                {periodos.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            )}
          </div>
          {loading && <div className="flex flex-col items-center py-16 gap-3"><div className="spinner" /><p className="text-gray-400 text-sm">Cargando...</p></div>}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" /><p className="flex-1 text-sm">{error}</p>
              <button onClick={load} className="flex items-center gap-1 text-sm underline"><RefreshCw className="w-4 h-4" /> Reintentar</button>
            </div>
          )}
          {!loading && !error && (
            <div className="card-tec overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full table-tec text-sm">
                  <thead><tr>
                    <th className="px-5 py-3 text-left text-xs uppercase">#</th>
                    <th className="px-5 py-3 text-left text-xs uppercase">Materia</th>
                    <th className="px-5 py-3 text-left text-xs uppercase">Periodo</th>
                    <th className="px-5 py-3 text-center text-xs uppercase">Calificacion</th>
                  </tr></thead>
                  <tbody className="divide-y divide-gray-100">
                    {filtered.length === 0 ? (
                      <tr><td colSpan={4} className="text-center py-12 text-gray-400">{items.length === 0 ? 'Sin datos' : 'Sin resultados'}</td></tr>
                    ) : filtered.map((item, i) => (
                      <tr key={i} className="hover:bg-gray-50 transition">
                        <td className="px-5 py-3 text-gray-400 text-xs">{i+1}</td>
                        <td className="px-5 py-3 font-medium text-gray-800">{getF(item,['materia','nombre_materia','nombre','asignatura']) || `Materia ${i+1}`}</td>
                        <td className="px-5 py-3 text-gray-500">{getF(item,['periodo','ciclo','semestre']) || 'pendiente'}</td>
                        <td className="px-5 py-3 text-center"><GradeBadge item={item} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filtered.length > 0 && <div className="px-5 py-2 border-t border-gray-100 text-xs text-gray-400">{filtered.length} de {items.length} materias</div>}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
