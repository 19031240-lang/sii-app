'use client';
import { useEffect, useState } from 'react';
import { getKardex, unwrap } from '@/lib/api';
import Header from '@/components/layout/Header';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface KardexItem { [key: string]: unknown }

function gradeColor(g: unknown): string {
  const n = Number(g);
  if (isNaN(n) || n === 0) return 'text-gray-400';
  if (n >= 80) return 'text-green-600 font-bold';
  if (n >= 70) return 'text-yellow-600 font-bold';
  return 'text-red-600 font-bold';
}

function getField(item: KardexItem, keys: string[]): string {
  for (const k of keys) if (item[k] !== undefined && item[k] !== null) return String(item[k]);
  return '—';
}

export default function KardexPage() {
  const [items, setItems] = useState<KardexItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  function load() {
    setLoading(true); setError('');
    getKardex()
      .then((data) => {
        const unwrapped = unwrap(data);
        const arr = Array.isArray(unwrapped) ? unwrapped : [unwrapped].filter(Boolean);
        setItems(arr as KardexItem[]);
      })
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(); }, []);

  // Agrupar por semestre
  const bySem: Record<string, KardexItem[]> = {};
  items.forEach(item => {
    const sem = getField(item, ['semestre','periodo','ciclo','sem']);
    if (!bySem[sem]) bySem[sem] = [];
    bySem[sem].push(item);
  });

  const grades = items.map(i => Number(getField(i,['calificacion','calif','grade','nota']))).filter(n => !isNaN(n) && n > 0);
  const promedio = grades.length ? (grades.reduce((a,b)=>a+b,0)/grades.length).toFixed(2) : '—';
  const creditos = items.reduce((s,i) => s + Number(getField(i,['creditos','cred','credits']) || 0), 0);
  const aprobadas = grades.filter(g => g >= 70).length;

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Kardex Académico" subtitle="Historial completo de materias cursadas" />
      <main className="flex-1 p-4 lg:p-6">
        <div className="max-w-5xl mx-auto fade-in space-y-5">

          {!loading && !error && items.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="card-tec p-4 text-center">
                <p className="text-2xl font-bold text-tec-blue">{items.length}</p>
                <p className="text-xs text-gray-400 mt-1">Materias</p>
              </div>
              <div className="card-tec p-4 text-center">
                <p className="text-2xl font-bold text-tec-green">{creditos}</p>
                <p className="text-xs text-gray-400 mt-1">Créditos</p>
              </div>
              <div className="card-tec p-4 text-center">
                <p className="text-2xl font-bold text-yellow-600">{promedio}</p>
                <p className="text-xs text-gray-400 mt-1">Promedio</p>
              </div>
              <div className="card-tec p-4 text-center">
                <p className="text-2xl font-bold text-green-600">{aprobadas}</p>
                <p className="text-xs text-gray-400 mt-1">Aprobadas</p>
              </div>
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center py-16 gap-3">
              <div className="spinner" /><p className="text-gray-400 text-sm">Cargando kardex...</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p className="flex-1 text-sm">{error}</p>
              <button onClick={load} className="flex items-center gap-1 text-sm underline">
                <RefreshCw className="w-4 h-4" /> Reintentar
              </button>
            </div>
          )}

          {!loading && !error && Object.entries(bySem).map(([sem, materias]) => (
            <div key={sem} className="card-tec overflow-hidden">
              <div className="bg-gradient-to-r from-tec-blue to-tec-blue-light px-5 py-3 flex items-center justify-between">
                <h3 className="text-white font-bold text-sm">Semestre / Periodo: {sem}</h3>
                <span className="text-white/60 text-xs">{materias.length} materias</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      {['Materia','Periodo','Créditos','Calificación','Estatus'].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {materias.map((item, i) => (
                      <tr key={i} className="hover:bg-gray-50 transition">
                        <td className="px-4 py-2.5 font-medium text-gray-800">
                          {getField(item,['materia','nombre_materia','nombre','asignatura',`M${i+1}`])}
                        </td>
                        <td className="px-4 py-2.5 text-gray-500 text-xs">{getField(item,['periodo','ciclo','semestre'])}</td>
                        <td className="px-4 py-2.5 text-center text-gray-600">{getField(item,['creditos','cred','credits'])}</td>
                        <td className={`px-4 py-2.5 text-center ${gradeColor(getField(item,['calificacion','calif','grade','nota']))}`}>
                          {getField(item,['calificacion','calif','grade','nota'])}
                        </td>
                        <td className="px-4 py-2.5">
                          <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                            {getField(item,['estatus','status','estado'])}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}

          {!loading && !error && items.length === 0 && (
            <div className="text-center py-20 text-gray-400">No hay datos de kardex disponibles</div>
          )}
        </div>
      </main>
    </div>
  );
}
