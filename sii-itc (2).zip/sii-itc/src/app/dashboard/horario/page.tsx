'use client';
import { useEffect, useState } from 'react';
import { getHorarios, unwrap } from '@/lib/api';
import Header from '@/components/layout/Header';
import { AlertCircle, RefreshCw, Clock, MapPin, User } from 'lucide-react';

interface HorarioItem { [key: string]: unknown }

const DIAS_ORDER = ['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
const DIA_COLORS: Record<string, { bg: string; border: string; header: string }> = {
  Lunes:     { bg: 'bg-blue-50',   border: 'border-blue-200',   header: 'bg-blue-600' },
  Martes:    { bg: 'bg-green-50',  border: 'border-green-200',  header: 'bg-green-600' },
  Miércoles: { bg: 'bg-purple-50', border: 'border-purple-200', header: 'bg-purple-600' },
  Jueves:    { bg: 'bg-yellow-50', border: 'border-yellow-200', header: 'bg-yellow-600' },
  Viernes:   { bg: 'bg-red-50',    border: 'border-red-200',    header: 'bg-red-600' },
  Sábado:    { bg: 'bg-orange-50', border: 'border-orange-200', header: 'bg-orange-500' },
};

function normDia(d: unknown): string {
  const s = String(d ?? '').trim().toLowerCase();
  const map: Record<string, string> = {
    lun:'Lunes', lunes:'Lunes',
    mar:'Martes', martes:'Martes',
    mie:'Miércoles', mié:'Miércoles', miercoles:'Miércoles', miércoles:'Miércoles', 'miã©rcoles':'Miércoles',
    jue:'Jueves', jueves:'Jueves',
    vie:'Viernes', viernes:'Viernes',
    sab:'Sábado', sáb:'Sábado', sabado:'Sábado', sábado:'Sábado',
  };
  return map[s] || String(d ?? '');
}

function getField(item: HorarioItem, keys: string[]): string {
  for (const k of keys) if (item[k] !== undefined && item[k] !== null && item[k] !== '') return String(item[k]);
  return '';
}

export default function HorarioPage() {
  const [items, setItems] = useState<HorarioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  function load() {
    setLoading(true); setError('');
    getHorarios()
      .then((data) => {
        const unwrapped = unwrap(data);
        const arr = Array.isArray(unwrapped) ? unwrapped : [unwrapped].filter(Boolean);
        setItems(arr as HorarioItem[]);
      })
      .catch((e: Error) => setError(e.message))
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(); }, []);

  const byDia: Record<string, HorarioItem[]> = {};
  items.forEach(item => {
    const dia = normDia(getField(item, ['dia','day','dia_semana','weekday']));
    if (!byDia[dia]) byDia[dia] = [];
    byDia[dia].push(item);
  });

  Object.values(byDia).forEach(clases =>
    clases.sort((a,b) => {
      const ha = getField(a,['hora_inicio','hora','start_time','time']);
      const hb = getField(b,['hora_inicio','hora','start_time','time']);
      return ha.localeCompare(hb);
    })
  );

  const diasConClases = DIAS_ORDER.filter(d => byDia[d]?.length > 0);

  return (
    <div className="flex flex-col min-h-screen">
      <Header title="Horario" subtitle="Clases organizadas por día del semestre actual" />
      <main className="flex-1 p-4 lg:p-6">
        <div className="max-w-5xl mx-auto fade-in">
          {loading && (
            <div className="flex flex-col items-center py-16 gap-3">
              <div className="spinner" /><p className="text-gray-400 text-sm">Cargando horario...</p>
            </div>
          )}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p className="flex-1 text-sm">{error}</p>
              <button onClick={load} className="flex items-center gap-1 text-sm underline">
                <RefreshCw className="w-4 h-4" /> Reintentar
              </button>
            </div>
          )}

          {!loading && !error && diasConClases.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {diasConClases.map(dia => {
                const c = DIA_COLORS[dia] ?? { bg:'bg-gray-50', border:'border-gray-200', header:'bg-gray-600' };
                return (
                  <div key={dia} className={`rounded-xl overflow-hidden border ${c.border} shadow-sm`}>
                    <div className={`${c.header} px-4 py-2.5 flex items-center justify-between`}>
                      <h3 className="text-white font-bold text-sm">{dia}</h3>
                      <span className="text-white/70 text-xs">{byDia[dia].length} clase{byDia[dia].length !== 1 ? 's':''}</span>
                    </div>
                    <div className={`${c.bg} p-3 space-y-2`}>
                      {byDia[dia].map((clase, i) => {
                        const materia = getField(clase,['materia','nombre_materia','nombre','asignatura']) || `Clase ${i+1}`;
                        const horaIni = getField(clase,['hora_inicio','hora','start_time']);
                        const horaFin = getField(clase,['hora_fin','end_time']);
                        const salon = getField(clase,['salon','aula','classroom','room']);
                        const maestro = getField(clase,['maestro','profesor','teacher','docente']);
                        const grupo = getField(clase,['grupo','group']);
                        return (
                          <div key={i} className="bg-white rounded-lg p-3 shadow-sm border border-white">
                            <p className="font-semibold text-gray-800 text-sm leading-tight">{materia}</p>
                            {(horaIni || horaFin) && (
                              <div className="flex items-center gap-1 text-xs text-gray-500 mt-1.5">
                                <Clock className="w-3 h-3 flex-shrink-0" />
                                <span>{horaIni}{horaFin ? ` — ${horaFin}` : ''}</span>
                              </div>
                            )}
                            {salon && (
                              <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
                                <MapPin className="w-3 h-3 flex-shrink-0" />
                                <span>Salón {salon}{grupo ? ` | Grupo ${grupo}` : ''}</span>
                              </div>
                            )}
                            {maestro && (
                              <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
                                <User className="w-3 h-3 flex-shrink-0" />
                                <span>{maestro}</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Fallback: tabla genérica si la API devuelve estructura diferente */}
          {!loading && !error && diasConClases.length === 0 && items.length > 0 && (
            <div className="card-tec overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full table-tec text-sm">
                  <thead>
                    <tr>
                      {Object.keys(items[0]).map(k => (
                        <th key={k} className="px-4 py-3 text-left text-xs uppercase">{k.replace(/_/g,' ')}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {items.map((item, i) => (
                      <tr key={i} className="hover:bg-gray-50 transition">
                        {Object.values(item).map((val, j) => (
                          <td key={j} className="px-4 py-2.5 text-gray-700 text-sm">{String(val ?? '—')}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {!loading && !error && items.length === 0 && (
            <div className="text-center py-20 text-gray-400">No hay horario disponible para este periodo.</div>
          )}
        </div>
      </main>
    </div>
  );
}
