import { NextRequest, NextResponse } from 'next/server';

const ALLOWED_ENDPOINTS = [
  '/movil/estudiante',
  '/movil/estudiante/calificaciones',
  '/movil/estudiante/kardex',
  '/movil/estudiante/horarios',
];

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const endpoint = decodeURIComponent(searchParams.get('endpoint') ?? '');
  const authHeader = request.headers.get('authorization');

  if (!endpoint) return NextResponse.json({ message: 'Endpoint requerido' }, { status: 400 });

  // Whitelist de endpoints permitidos (evita SSRF)
  const allowed = ALLOWED_ENDPOINTS.some(e => endpoint.startsWith(e));
  if (!allowed) {
    return NextResponse.json({ message: 'Endpoint no permitido' }, { status: 403 });
  }

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return NextResponse.json({ message: 'Token requerido' }, { status: 401 });
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const url = `https://sii.celaya.tecnm.mx/api${endpoint}`;
    const response = await fetch(url, {
      headers: {
        Authorization: authHeader,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    const text = await response.text();
    let data: unknown;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }

    return NextResponse.json(data, { status: response.status });
  } catch (err: unknown) {
    if (err instanceof Error && err.name === 'AbortError') {
      return NextResponse.json({ message: 'Tiempo de espera agotado.' }, { status: 504 });
    }
    return NextResponse.json({ message: 'Error al conectar con SII.' }, { status: 503 });
  } finally {
    clearTimeout(timeout);
  }
}
