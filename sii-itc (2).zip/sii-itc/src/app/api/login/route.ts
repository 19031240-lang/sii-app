import { NextRequest, NextResponse } from 'next/server';

function sanitize(str: string): string {
  return str.replace(/[<>"'`]/g, '').trim().substring(0, 200);
}

export async function POST(request: NextRequest) {
  try {
    const contentType = request.headers.get('content-type') ?? '';
    if (!contentType.includes('application/json')) {
      return NextResponse.json({ message: 'Content-Type inválido' }, { status: 400 });
    }

    const body = await request.json().catch(() => null);
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ message: 'Cuerpo de solicitud inválido' }, { status: 400 });
    }

    const email = sanitize(String(body.email ?? ''));
    const password = String(body.password ?? '').substring(0, 200);

    if (!email || !password) {
      return NextResponse.json({ message: 'Correo y contraseña son requeridos' }, { status: 400 });
    }

    // Validar formato de email básico
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ message: 'Formato de correo inválido' }, { status: 400 });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    let response: Response;
    try {
      response = await fetch('https://sii.celaya.tecnm.mx/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ email, password }),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }

    const text = await response.text();
    let data: Record<string, unknown>;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }

    if (!response.ok) {
      return NextResponse.json(
        { message: String(data.message ?? data.error ?? 'Credenciales incorrectas') },
        { status: response.status }
      );
    }

    // Extraer token de cualquier clave posible
    const token =
      data.token ?? data.access_token ?? data.jwt ??
      (data.data as Record<string,unknown>)?.token ??
      (data.data as Record<string,unknown>)?.access_token;

    if (!token) {
      return NextResponse.json({ message: 'El servidor no devolvió un token válido' }, { status: 502 });
    }

    return NextResponse.json({ token, ...data }, { status: 200 });
  } catch (err: unknown) {
    if (err instanceof Error && err.name === 'AbortError') {
      return NextResponse.json({ message: 'El servidor SII tardó demasiado. Intente de nuevo.' }, { status: 504 });
    }
    console.error('[LOGIN ERROR]', err);
    return NextResponse.json({ message: 'No se pudo conectar con el servidor SII.' }, { status: 503 });
  }
}
