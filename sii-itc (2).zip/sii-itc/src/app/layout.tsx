import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SII ITC Celaya - Sistema de Información Institucional',
  description: 'Portal estudiantil del Tecnológico Nacional de México en Celaya',
  icons: { icon: '/images/logo.png' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
