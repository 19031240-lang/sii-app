export const TOKEN_KEY = 'sii_token';

export function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
}

export function setToken(token: string): void {
  if (typeof window !== 'undefined') {
    try { localStorage.setItem(TOKEN_KEY, token); } catch {}
  }
}

export function removeToken(): void {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem('student_photo');
    } catch {}
  }
}

export function isAuthenticated(): boolean {
  return !!getToken();
}

// Desenvuelve cualquier estructura de respuesta de la API del SII
export function unwrap(raw: unknown): unknown {
  if (raw === null || raw === undefined) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw !== 'object') return raw;
  const r = raw as Record<string, unknown>;
  // Prioridad: data > entidades conocidas > único valor objeto/array
  if (r.data !== undefined) return r.data;
  const entityKeys = ['estudiante','calificaciones','kardex','horarios','horario','materias'];
  for (const k of entityKeys) {
    if (r[k] !== undefined) return r[k];
  }
  const skip = new Set(['success','status','message','code','token','access_token','jwt']);
  const keys = Object.keys(r).filter(k => !skip.has(k));
  if (keys.length === 1) {
    const v = r[keys[0]];
    if (Array.isArray(v) || (typeof v === 'object' && v !== null)) return v;
  }
  return raw;
}

async function apiFetch<T>(endpoint: string): Promise<T> {
  const token = getToken();
  if (!token) {
    if (typeof window !== 'undefined') window.location.href = '/login';
    throw new Error('Sin sesión activa');
  }

  const response = await fetch(
    `/api/proxy?endpoint=${encodeURIComponent(endpoint)}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      cache: 'no-store',
    }
  );

  const text = await response.text();
  let data: unknown;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }

  if (response.status === 401) {
    removeToken();
    if (typeof window !== 'undefined') window.location.href = '/login';
    throw new Error('Sesión expirada. Inicia sesión nuevamente.');
  }

  if (!response.ok) {
    const d = data as Record<string, unknown>;
    throw new Error(String(d?.message ?? d?.error ?? `Error ${response.status}`));
  }

  return data as T;
}

export async function loginUser(email: string, password: string) {
  const response = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ email, password }),
    cache: 'no-store',
  });
  const text = await response.text();
  let data: Record<string, unknown>;
  try { data = JSON.parse(text); } catch { data = { message: 'Respuesta inválida del servidor' }; }
  if (!response.ok) throw new Error(String(data.message ?? data.error ?? 'Credenciales incorrectas'));
  return data;
}

export async function getEstudiante() { return apiFetch('/movil/estudiante'); }
export async function getCalificaciones() { return apiFetch('/movil/estudiante/calificaciones'); }
export async function getKardex() { return apiFetch('/movil/estudiante/kardex'); }
export async function getHorarios() { return apiFetch('/movil/estudiante/horarios'); }
