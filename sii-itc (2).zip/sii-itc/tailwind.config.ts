/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        tec: {
          green: '#006633',
          'green-light': '#009944',
          'green-dark': '#004422',
          blue: '#003F8A',
          'blue-light': '#0055B3',
          'blue-dark': '#002A5C',
          white: '#FFFFFF',
          gray: '#F4F6F9',
          'gray-dark': '#6B7280',
        },
      },
      fontFamily: {
        sans: ['Montserrat', 'sans-serif'],
        display: ['Oswald', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
